// Fill out your copyright notice in the Description page of Project Settings.


#include "SlateWidgets/AdvanceDeletionWidget.h"

#include "AtsukkoToolKit.h"
#include "DebugHeader.h"

#define LIST_ALL TEXT("List All Available Assets")
#define LIST_UNUSED TEXT("List Unused Assets")
#define LIST_SAME_NAME TEXT("List Assets With Same Name")

void SAdvanceDeletionTab::Construct(const FArguments& InArgs)
{
	bCanSupportFocus = true;

	StoredAssetsData = InArgs._AssetsDataToStore;
	DisplayedAssetsData = InArgs._AssetsDataToStore;
	FSlateFontInfo TitleTextFont = GetEmbossedTextFont();
	TitleTextFont.Size = 30;

	FString HelpText = FString(TEXT("Specify the listing condition in the drop. Double click to locate the asset in browser."));
	FSlateFontInfo HelpTextFont = GetEmbossedTextFont();
	HelpTextFont.Size = 10;

	CheckBoxArray.Empty();
	AssetDataToDeleteArray.Empty();
	ComboBoxSourceItems.Empty();

	ComboBoxSourceItems.Add(MakeShared<FString>(LIST_ALL));
	ComboBoxSourceItems.Add(MakeShared<FString>(LIST_UNUSED));
	ComboBoxSourceItems.Add(MakeShared<FString>(LIST_SAME_NAME));

	ChildSlot
	[
		SNew(SVerticalBox)

		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Advance Deletion")))
			.Font(TitleTextFont)
			.Justification(ETextJustify::Center)
			.ColorAndOpacity(FColor::White)
		]

		// Slot for combo box.
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)

			+SHorizontalBox::Slot()
			.AutoWidth()
			[
				ConstructComboBox()
			]

			+SHorizontalBox::Slot()
			.FillWidth(.6f)
			[
				ConstructTextForHelp(HelpText, HelpTextFont, ETextJustify::Center)
			]

			+SHorizontalBox::Slot()
			.FillWidth(.1f)
			[
				ConstructTextForHelp(TEXT("Current Folder:\n") + InArgs._CurrenSelectedFolder, HelpTextFont, ETextJustify::Right)
			]
		]

		// Slot for scroll box.
		+SVerticalBox::Slot()
		.VAlign(VAlign_Fill)
		[
			SNew(SScrollBox)

			+SScrollBox::Slot()
			[
				ConstructAssetListView()
			]
		]

		// Slot for tab buttons.
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SHorizontalBox)

			+SHorizontalBox::Slot()
			.FillWidth(10.f)
			.Padding(5)
			[
				ConstructDeleteAllButton()
			]
			+SHorizontalBox::Slot()
			.FillWidth(10.f)
			.Padding(5)
			[
				ConstructSelectAllButton()
			]
			+SHorizontalBox::Slot()
			.FillWidth(10.f)
			.Padding(5)
			[
				ConstructDeselectAllButton()
			]
		]
	];
}

void SAdvanceDeletionTab::OnRowWidgetMouseButtonClicked(TSharedPtr<FAssetData> ClickedData)
{
	FAtsukkoToolKitModule AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));
	AtsukkoToolKitModule.SyncCBToClickedAssetForAssetList(ClickedData->GetSoftObjectPath().ToString());
}

TSharedRef<SListView<TSharedPtr<FAssetData>>> SAdvanceDeletionTab::ConstructAssetListView()
{
	ConstructedAssetListView = SNew(SListView<TSharedPtr<FAssetData>>)
		.ItemHeight(24.f)
		.ListItemsSource(&DisplayedAssetsData)
		.OnGenerateRow(this, &SAdvanceDeletionTab::OnGenerateRowForList)
		.OnMouseButtonDoubleClick(this, &SAdvanceDeletionTab::OnRowWidgetMouseButtonClicked);
	
	return ConstructedAssetListView.ToSharedRef();
}

void SAdvanceDeletionTab::RefreshAssetListView()
{
	CheckBoxArray.Empty();
	AssetDataToDeleteArray.Empty();
	if(ConstructedAssetListView.IsValid())
	{
		ConstructedAssetListView->RebuildList();
	}
}

TSharedRef<STextBlock> SAdvanceDeletionTab::ConstructTextForHelp(const FString& TextContent,
	const FSlateFontInfo& FontToUse, ETextJustify::Type TextJustify)
{
	auto ConstructedTextBlock = SNew(STextBlock)
	.Text(FText::FromString(TextContent))
	.Font(FontToUse)
	.ColorAndOpacity(FColor::White)
	.Justification(TextJustify)
	.AutoWrapText(true);

	return ConstructedTextBlock;
}

#pragma region ComboBoxForListingCondition

// Construct drop-down list.
TSharedRef<SComboBox<TSharedPtr<FString>>> SAdvanceDeletionTab::ConstructComboBox()
{
	TSharedRef<SComboBox<TSharedPtr<FString>>> ConstructedComboBox = SNew(SComboBox<TSharedPtr<FString>>)
		.OptionsSource(&ComboBoxSourceItems)
		.OnGenerateWidget(this, &SAdvanceDeletionTab::OnGenerateComboContent)
		.OnSelectionChanged(this, &SAdvanceDeletionTab::OnComboSelectionChanged)
		[
			SAssignNew(ComboDisplayTextBlock, STextBlock)
			.Text(FText::FromString(TEXT("List Assets Option")))
		];

	return ConstructedComboBox;
}

// Set drop_down rows.
TSharedRef<SWidget> SAdvanceDeletionTab::OnGenerateComboContent(TSharedPtr<FString> SourceItem)
{
	TSharedRef<STextBlock> ConstructedComboText = SNew(STextBlock)
	.Text(FText::FromString(*SourceItem.Get()));

	return ConstructedComboText;
}

// Called when option changed.
void SAdvanceDeletionTab::OnComboSelectionChanged(TSharedPtr<FString> SelectedOption, ESelectInfo::Type InSelectInfo)
{
	ComboDisplayTextBlock->SetText(FText::FromString(*SelectedOption.Get()));

	FAtsukkoToolKitModule AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));
	
	if(*SelectedOption.Get() == LIST_ALL)
	{
		DisplayedAssetsData = StoredAssetsData;
		RefreshAssetListView();
	}
	else if(*SelectedOption.Get() == LIST_UNUSED)
	{
		AtsukkoToolKitModule.ListUnusedAssetsForAssetList(StoredAssetsData, DisplayedAssetsData);
		RefreshAssetListView();
	}
	else if(*SelectedOption.Get() == LIST_SAME_NAME)
	{
		AtsukkoToolKitModule.ListRepeatedNameAssetsForAssetList(StoredAssetsData, DisplayedAssetsData);
		RefreshAssetListView();
	}
}

#pragma endregion

#pragma region RowWidgetForAssetListView


TSharedRef<ITableRow> SAdvanceDeletionTab::OnGenerateRowForList(TSharedPtr<FAssetData> AssetDataToDisplay,
                                                                const TSharedRef<STableViewBase>& OwnerTable)
{
	if(!AssetDataToDisplay.IsValid()) return SNew(STableRow<TSharedPtr<FAssetData>>, OwnerTable);

	const FString DisplayAssetClassName = AssetDataToDisplay->GetClass()->GetName();
	FSlateFontInfo AssetClassNameFont = GetEmbossedTextFont();
	AssetClassNameFont.Size = 10;
	
	const FString DisplayAssetName = AssetDataToDisplay->AssetName.ToString();
	FSlateFontInfo AssetNameFont = GetEmbossedTextFont();
	AssetNameFont.Size = 15;
	
	TSharedRef<STableRow<TSharedPtr<FAssetData>>> ListViewRowWidget =
		SNew(STableRow<TSharedPtr<FAssetData>>, OwnerTable)
		.Padding(FMargin(5.f))
		[
			SNew(SHorizontalBox)

			// Slot for check box.
			+SHorizontalBox::Slot()
			.HAlign(HAlign_Left)
			.VAlign(VAlign_Center)
			.FillWidth(.05f)
			[
				ConstructCheckBox(AssetDataToDisplay)
			]

			// Slot for asset class name.
			+SHorizontalBox::Slot()
			.HAlign(HAlign_Center)
			.VAlign(VAlign_Fill)
			.FillWidth(.5f)
			[
				ConstructTextForRowWidget(DisplayAssetClassName, AssetClassNameFont)
			]
			
			// Slot for asset name.
			+SHorizontalBox::Slot()
			.HAlign(HAlign_Left)
			.VAlign(VAlign_Fill)
			[
				ConstructTextForRowWidget(DisplayAssetName, AssetNameFont)
			]

			// Slot for button.
			+SHorizontalBox::Slot()
			.HAlign(HAlign_Right)
			.VAlign(VAlign_Fill)
			[
				ConstructButtonForRowWidget(AssetDataToDisplay)
			]
			
		];
	return ListViewRowWidget;
}

TSharedRef<SCheckBox> SAdvanceDeletionTab::ConstructCheckBox(const TSharedPtr<FAssetData>& AssetDataToDisplay)
{
	TSharedRef<SCheckBox> ConstructedCheckBox =
		SNew(SCheckBox)
	.Type(ESlateCheckBoxType::CheckBox)
	.OnCheckStateChanged(this, &SAdvanceDeletionTab::OnCheckBoxStateChanged, AssetDataToDisplay)
	.Visibility(EVisibility::Visible);

	CheckBoxArray.Add(ConstructedCheckBox);

	return ConstructedCheckBox;
}

void SAdvanceDeletionTab::OnCheckBoxStateChanged(ECheckBoxState NewState, TSharedPtr<FAssetData> AssetData)
{
	switch (NewState)
	{
	case ECheckBoxState::Unchecked:
		if(AssetDataToDeleteArray.Contains(AssetData))
		{
			AssetDataToDeleteArray.Remove(AssetData);
		}
		break;
		
	case ECheckBoxState::Checked:
		AssetDataToDeleteArray.AddUnique(AssetData);
		break;
		
	case ECheckBoxState::Undetermined:
		DebugHeader::Print(AssetData->AssetName.ToString() + TEXT(" Undetermined"));
		break;
		
	default:
		break;
	}
}

TSharedRef<STextBlock> SAdvanceDeletionTab::ConstructTextForRowWidget(const FString& TextContent, const FSlateFontInfo& FontToUse)
{
	TSharedRef<STextBlock> ConstructedTextBlock = SNew(STextBlock)
		.Text(FText::FromString(TextContent))
		.Font(FontToUse)
		.ColorAndOpacity(FColor::White);
	
	return ConstructedTextBlock;
}

TSharedRef<SButton> SAdvanceDeletionTab::ConstructButtonForRowWidget(const TSharedPtr<FAssetData>& AssetDataToDisplay)
{
	TSharedRef<SButton> ConstructedButton = SNew(SButton)
		.Text(FText::FromString("Delete"))
		.OnClicked(this, &SAdvanceDeletionTab::OnDeleteButtonClicked, AssetDataToDisplay);
	
		return ConstructedButton;
}

FReply SAdvanceDeletionTab::OnDeleteButtonClicked(TSharedPtr<FAssetData> ClickedAssetData)
{
	FAtsukkoToolKitModule AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));
	const bool bAssetDeleted = AtsukkoToolKitModule.DeleteSingleAssetForAssetList(*ClickedAssetData.Get());

	if(bAssetDeleted)
	{
		if(StoredAssetsData.Contains(ClickedAssetData))
		{
			StoredAssetsData.Remove(ClickedAssetData);
		}
		if(DisplayedAssetsData.Contains(ClickedAssetData))
		{
			DisplayedAssetsData.Remove(ClickedAssetData);
		}
		RefreshAssetListView();
	}
	
	return FReply::Handled();
}

#pragma endregion

#pragma region TabButtons

TSharedRef<SButton> SAdvanceDeletionTab::ConstructDeleteAllButton()
{
	TSharedRef<SButton> ConstructedDeleteAllButton = SNew(SButton)
		.ContentPadding(FMargin(5.f))
		.OnClicked(this, &SAdvanceDeletionTab::OnDeleteAllButtonClicked);

	ConstructedDeleteAllButton->SetContent(ConstructTextForTabButton(TEXT("Delete All")));
	
	return ConstructedDeleteAllButton;
}

TSharedRef<SButton> SAdvanceDeletionTab::ConstructSelectAllButton()
{
	TSharedRef<SButton> ConstructedSelectAllButton = SNew(SButton)
		.ContentPadding(FMargin(5.f))
		.OnClicked(this, &SAdvanceDeletionTab::OnSelectAllButtonClicked);
	
	ConstructedSelectAllButton->SetContent(ConstructTextForTabButton(TEXT("Select All")));
	
	return ConstructedSelectAllButton;
}

TSharedRef<SButton> SAdvanceDeletionTab::ConstructDeselectAllButton()
{
	TSharedRef<SButton> ConstructedDeselectAllButton = SNew(SButton)
		.ContentPadding(FMargin(5.f))
		.OnClicked(this, &SAdvanceDeletionTab::OnDeselectAllButtonClicked);
	
	ConstructedDeselectAllButton->SetContent(ConstructTextForTabButton(TEXT("Deselect All")));
	
	return ConstructedDeselectAllButton;
}

FReply SAdvanceDeletionTab::OnDeleteAllButtonClicked()
{
	if(AssetDataToDeleteArray.Num() == 0)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("No asset currently selected"));
		return FReply::Handled();
	}

	TArray<FAssetData> AssetDataToDelete;

	for(const TSharedPtr<FAssetData>& AssetData : AssetDataToDeleteArray)
	{
		AssetDataToDelete.Add(*AssetData.Get());
	}

	FAtsukkoToolKitModule AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));

	bool bAssetsDeleted = AtsukkoToolKitModule.DeleteMultipleAssetsForAssetList(AssetDataToDelete);

	if(bAssetsDeleted)
	{
		for(const TSharedPtr<FAssetData>& AssetData : AssetDataToDeleteArray)
		{
			if(StoredAssetsData.Contains(AssetData))
			{
				StoredAssetsData.Remove(AssetData);
			}
			if(DisplayedAssetsData.Contains(AssetData))
			{
				DisplayedAssetsData.Remove(AssetData);
			}
		}
		RefreshAssetListView();
	}
	
	return FReply::Handled();
}

FReply SAdvanceDeletionTab::OnSelectAllButtonClicked()
{
	if(CheckBoxArray.Num() > 0)
	{
		for (TSharedRef<SCheckBox> CheckBox : CheckBoxArray)
		{
			if(!CheckBox->IsChecked())
			{
				CheckBox->ToggleCheckedState();
			}
		}
	}
	return FReply::Handled();
}

FReply SAdvanceDeletionTab::OnDeselectAllButtonClicked()
{
	if(CheckBoxArray.Num() > 0)
	{
		for (TSharedRef<SCheckBox> CheckBox : CheckBoxArray)
		{
			if(CheckBox->IsChecked())
			{
				CheckBox->ToggleCheckedState();
			}
		}
	}
	return FReply::Handled();
}

TSharedRef<STextBlock> SAdvanceDeletionTab::ConstructTextForTabButton(const FString& TextContent)
{
	FSlateFontInfo ButtonTextFont = GetEmbossedTextFont();
	ButtonTextFont.Size = 15;

	TSharedRef<STextBlock> ConstructedTextBlock = SNew(STextBlock)
		.Text(FText::FromString(TextContent))
		.Font(ButtonTextFont)
		.Justification(ETextJustify::Center);

	return ConstructedTextBlock;
}

#pragma endregion
