// Fill out your copyright notice in the Description page of Project Settings.


#include "CustomOutlinerColumn/OutlinerSelectionColumn.h"

#include "ActorTreeItem.h"
#include "AtsukkoToolKit.h"
#include "ISceneOutlinerTreeItem.h"
#include "CustomStyle/AtsukkoToolKitStyle.h"

SHeaderRow::FColumn::FArguments FOutlinerSelectionLockColumn::ConstructHeaderRowColumn()
{
	SHeaderRow::FColumn::FArguments ConstructedHeaderRow =
		SHeaderRow::Column(GetColumnID())
		.FixedWidth(24.f)
		.HAlignHeader(HAlign_Center)
		.VAlignHeader(VAlign_Center)
		.HAlignCell(HAlign_Center)
		.VAlignCell(VAlign_Center)
		.DefaultTooltip(FText::FromString(TEXT("Actor Selection Lock - Press icon to lock actor selection")))
		[
			SNew(SImage)
			.ColorAndOpacity(FSlateColor::UseForeground())
			.Image(FAtsukkoToolKitStyle::GetCreatedSlateStyleSet()->GetBrush(FName(TEXT("ContentBrowser.AtsukkoIcon"))))
		];

	return ConstructedHeaderRow;
}

const TSharedRef<SWidget> FOutlinerSelectionLockColumn::ConstructRowWidget(FSceneOutlinerTreeItemRef TreeItem,
	const STableRow<FSceneOutlinerTreeItemPtr>& Row)
{
	FActorTreeItem* ActorTreeItem = TreeItem->CastTo<FActorTreeItem>();

	if(!ActorTreeItem || !ActorTreeItem->IsValid()) return SNullWidget::NullWidget;

	FAtsukkoToolKitModule& AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));

	const bool bIsActorSelectionLocked =AtsukkoToolKitModule.CheckIsActorSelectionLocked(ActorTreeItem->Actor.Get());

	const FCheckBoxStyle& ToggleButtonStyle = FAtsukkoToolKitStyle::GetCreatedSlateStyleSet()->GetWidgetStyle<
		FCheckBoxStyle>(FName("SceneOutliner.SelectionLock"));
	
	TSharedRef<SCheckBox> ConstructedRowWidget =
		SNew(SCheckBox)
		.Visibility(EVisibility::Visible)
		.Type(ESlateCheckBoxType::ToggleButton)
		.Style(&ToggleButtonStyle)
		.HAlign(HAlign_Center)
		.IsChecked(bIsActorSelectionLocked ? ECheckBoxState::Checked : ECheckBoxState::Unchecked)
		.OnCheckStateChanged(this, &FOutlinerSelectionLockColumn::OnRowWidgetCheckChanged, ActorTreeItem->Actor);

	return ConstructedRowWidget;
}

void FOutlinerSelectionLockColumn::OnRowWidgetCheckChanged(ECheckBoxState NewState,
	TWeakObjectPtr<AActor> CorrespondingActor)
{
	FAtsukkoToolKitModule& AtsukkoToolKitModule = FModuleManager::LoadModuleChecked<FAtsukkoToolKitModule>(
		TEXT("AtsukkoToolKit"));

	switch (NewState)
	{
	case ECheckBoxState::Unchecked:
		AtsukkoToolKitModule.ProcessLockingForOutliner(CorrespondingActor.Get(), false);
		break;
	case ECheckBoxState::Checked:
		AtsukkoToolKitModule.ProcessLockingForOutliner(CorrespondingActor.Get(), true);
		break;
	case ECheckBoxState::Undetermined:
		break;
	}
}

