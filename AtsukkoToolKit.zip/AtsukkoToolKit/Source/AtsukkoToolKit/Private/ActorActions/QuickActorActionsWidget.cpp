// Fill out your copyright notice in the Description page of Project Settings.


#include "ActorActions/QuickActorActionsWidget.h"

#include "DebugHeader.h"
#include "Subsystems/EditorActorSubsystem.h"

void UQuickActorActionsWidget::SelectAllActorsWithSimilarName()
{
	if(!GetEditorActorSubsystem()) return;

	TArray<AActor*> SelectedActors = EditorActorSubsystem->GetSelectedLevelActors();
	uint32 SelectionCounter = 0;

	if(SelectedActors.Num() == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No actor selected."));
		return;
	}

	if(SelectedActors.Num() > 1)
	{
		DebugHeader::ShowNotifyInfo(TEXT("You can only select 1 actor."));
		return;
	}

	FString SelectedActorName = SelectedActors[0]->GetActorLabel();
	FString NameToSearch = SelectedActorName.LeftChop(4);

	TArray<AActor*> AllActors = EditorActorSubsystem->GetAllLevelActors();

	for (AActor* ActorInLevel : AllActors)
	{
		if(!ActorInLevel) continue;

		if(ActorInLevel->GetActorLabel().Contains(NameToSearch, SearchCase))
		{
			EditorActorSubsystem->SetActorSelectionState(ActorInLevel, true);
			SelectionCounter++;
		}
	}

	if(SelectionCounter > 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("Successfully selected " + FString::FromInt(SelectionCounter) + TEXT(" actors.")));
	}
	else
	{
		DebugHeader::ShowNotifyInfo(TEXT("No actor with similar name found."));
	}
}

#pragma region ActorBatchDuplication

void UQuickActorActionsWidget::DuplicateActors()
{
	if(!GetEditorActorSubsystem()) return;

	TArray<class AActor*> SelectedActors = EditorActorSubsystem->GetSelectedLevelActors();

	if(SelectedActors.Num() == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No actor selected."));
		return;
	}

	if(NumberOfDuplicates <= 0 || Offset == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("Did not specify a number of duplications or an offset distance."));
		return;
	}

	int32 Counter = 0;
	for(AActor* SelectedActor : SelectedActors)
	{
		if(!SelectedActor) continue;

		for(int32 i = 0; i < NumberOfDuplicates; i++)
		{
			AActor* DuplicatedActor = EditorActorSubsystem->DuplicateActor(SelectedActor, SelectedActor->GetWorld());
			
			if(!DuplicatedActor) continue;

			const float DuplicationOffsetDist = (i + 1) * Offset;
			switch (AxisForDuplication)
			{
				case E_DuplicationAxis::EDA_XAxis:
					DuplicatedActor->AddActorWorldOffset(FVector(DuplicationOffsetDist, 0.f, 0.f));
					break;
				case E_DuplicationAxis::EDA_YAxis:
					DuplicatedActor->AddActorWorldOffset(FVector(0.f, DuplicationOffsetDist, 0.f));
					break;
				case E_DuplicationAxis::EDA_ZAxis:
					DuplicatedActor->AddActorWorldOffset(FVector(0.f, 0.f, DuplicationOffsetDist));
					break;
				case E_DuplicationAxis::EDA_MAX:
					break;
				default:
					break;
			}

			EditorActorSubsystem->SetActorSelectionState(DuplicatedActor, true);
			Counter++;
		}

	}
	if(Counter > 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("Successfully duplicated " + FString::FromInt(Counter) + " actors."));
	}
}

#pragma endregion

#pragma region RandomizeActorTransform
void UQuickActorActionsWidget::RandomizeActorTransform()
{
	const bool ConditionNotSet = !RandomActorRotation.bRandomizeRotYaw && !RandomActorRotation.bRandomizeRotPitch && !RandomActorRotation.bRandomizeRotRoll && !RandomActorOffset.bRandomizeOffsetX && !RandomActorOffset.bRandomizeOffsetY && !RandomActorOffset.bRandomizeOffsetZ && !RandomActorScale.bRandomScale;
	if(ConditionNotSet)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No variation condition specified."));
		return;
	}
	if(!GetEditorActorSubsystem()) return;

	TArray<class AActor*> SelectedActors = EditorActorSubsystem->GetSelectedLevelActors();
	if(SelectedActors.Num() == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No actor selected."));
		return;
	}

	int32 Counter = 0;
	for(AActor* SelectedActor : SelectedActors)
	{
		if(!SelectedActor) continue;

		float RandomRotYawValue = 0.f;
		float RandomRotPitchValue = 0.f;
		float RandomRotRollValue = 0.f;
		if(RandomActorRotation.bRandomizeRotYaw)
		{
			RandomRotYawValue = FMath::RandRange(RandomActorRotation.RotYawMin, RandomActorRotation.RotYawMax);
		}
		if(RandomActorRotation.bRandomizeRotPitch)
		{
			RandomRotPitchValue = FMath::RandRange(RandomActorRotation.RotPitchMin, RandomActorRotation.RotPitchMax);
		}
		if(RandomActorRotation.bRandomizeRotRoll)
		{
			RandomRotRollValue = FMath::RandRange(RandomActorRotation.RotRollMin, RandomActorRotation.RotRollMax);
		}
		const FRotator RandomRotator = FRotator(RandomRotPitchValue, RandomRotYawValue, RandomRotRollValue);
		SelectedActor->AddActorWorldRotation(RandomRotator);


		float RandomOffsetXValue = 0.f;
		float RandomOffsetYValue = 0.f;
		float RandomOffsetZValue = 0.f;
		if(RandomActorOffset.bRandomizeOffsetX)
		{
			RandomOffsetXValue = FMath::RandRange(RandomActorOffset.OffsetXMin, RandomActorOffset.OffsetXMax);
		}
		if(RandomActorOffset.bRandomizeOffsetY)
		{
			RandomOffsetYValue = FMath::RandRange(RandomActorOffset.OffsetYMin, RandomActorOffset.OffsetYMax);
		}
		if(RandomActorOffset.bRandomizeOffsetZ)
		{
			RandomOffsetZValue = FMath::RandRange(RandomActorOffset.OffsetZMin, RandomActorOffset.OffsetZMax);
		}
		const FVector RandomOffset = FVector(RandomOffsetXValue, RandomOffsetYValue, RandomOffsetZValue);
		SelectedActor->AddActorWorldOffset(RandomOffset);

		
		FVector RandomScale(1.f, 1.f, 1.f);
		float RandVal = 1.f;
		float RandValX = 1.f;
		float RandValY = 1.f;
		float RandValZ = 1.f;
		switch (RandomActorScale.RandomScaleMode)
		{
		case E_RandomScaleMode::DRSM_Uniform:
			RandVal = FMath::RandRange(RandomActorScale.ScaleMin, RandomActorScale.ScaleMax);
			RandomScale = FVector(RandVal, RandVal, RandVal);
			break;
		case E_RandomScaleMode::DRSM_Specific:
			if(RandomActorScale.bRandomizeScaleX)
			{
				RandValX = FMath::RandRange(RandomActorScale.ScaleXMin, RandomActorScale.ScaleXMax);
			}
			if(RandomActorScale.bRandomizeScaleY)
			{
				RandValY = FMath::RandRange(RandomActorScale.ScaleYMin, RandomActorScale.ScaleYMax);
			}
			if(RandomActorScale.bRandomizeScaleZ)
			{
				RandValZ = FMath::RandRange(RandomActorScale.ScaleZMin, RandomActorScale.ScaleZMax);
			}
			RandomScale = FVector(RandValX, RandValY, RandValZ);
			break;
		case E_RandomScaleMode::DRSM_Max:
			break;
		}
		SelectedActor->SetActorScale3D(RandomScale);
		

		Counter++;
	}
	if(Counter > 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("Successfully set " + FString::FromInt(Counter) + " actors."));
		
	}
}
#pragma endregion

bool UQuickActorActionsWidget::GetEditorActorSubsystem()
{
	if(!EditorActorSubsystem)
	{
		EditorActorSubsystem = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
	}
	return EditorActorSubsystem != nullptr;
}
