// Copyright Epic Games, Inc. All Rights Reserved.

#include "AtsukkoToolKit.h"

#include "AssetToolsModule.h"
#include "ContentBrowserModule.h"
#include "DebugHeader.h"
#include "EditorAssetLibrary.h"
#include "LevelEditor.h"
#include "ObjectTools.h"
#include "Selection.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "CustomOutlinerColumn/OutlinerSelectionColumn.h"
#include "CustomStyle/AtsukkoToolKitStyle.h"
#include "Editor/SceneOutliner/Public/SceneOutlinerModule.h"
#include "SlateWidgets/AdvanceDeletionWidget.h"
#include "Subsystems/EditorActorSubsystem.h"

#define LOCTEXT_NAMESPACE "FAtsukkoToolKitModule"

void FAtsukkoToolKitModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	FAtsukkoToolKitStyle::InitializeIcons();
	InitCBMenuExtension();
	RegisterAdvanceDeletionTab();
	InitLevelEditorExtension();
	InitCustomSelectionEvent();
	InitSceneOutlinerColumnExtension();
}

void FAtsukkoToolKitModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(FName("Advance Deletion"));
	FAtsukkoToolKitStyle::ShutDown();
	
	UnRegisterSceneOutlinerColumnExtension();
}

























#pragma region ContentBrowserMenuExtension

void FAtsukkoToolKitModule::InitCBMenuExtension()
{
	FContentBrowserModule& ContentBrowserModule =
	FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));

	TArray<FContentBrowserMenuExtender_SelectedPaths>& ContentBrowserModuleMenuExtenders = 
	ContentBrowserModule.GetAllPathViewContextMenuExtenders();

	ContentBrowserModuleMenuExtenders.Add(FContentBrowserMenuExtender_SelectedPaths::CreateRaw(this, &FAtsukkoToolKitModule::CustomCBMenuExtender));
}

TSharedRef<FExtender> FAtsukkoToolKitModule::CustomCBMenuExtender(const TArray<FString>& SelectedPaths)
{
	TSharedRef<FExtender> MenuExtender (new FExtender());

	if(SelectedPaths.Num() > 0)
	{
		MenuExtender->AddMenuExtension(
			FName("Delete"),
			EExtensionHook::After,
			nullptr,
			FMenuExtensionDelegate::CreateRaw(this, &FAtsukkoToolKitModule::AddCBMenuEntry));

		FolderPathsSelected = SelectedPaths;
	}
	
	return MenuExtender;
}

void FAtsukkoToolKitModule::AddCBMenuEntry(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		FText::FromString(TEXT("Delete Unused Assets")),
		FText::FromString(TEXT("Safely delete unused assets under folder.")), 
		FSlateIcon(FAtsukkoToolKitStyle::GetStyleSetName(), TEXT("ContentBrowser.AtsukkoIcon")), 
		FExecuteAction::CreateRaw(this, &FAtsukkoToolKitModule::OnDeleteUnusedAssetsButtonClicked));

	MenuBuilder.AddMenuEntry(FText::FromString(TEXT("Delete Empty Folders")),
		FText::FromString(TEXT("Delete empty folders under selected folders.")),
		FSlateIcon(FAtsukkoToolKitStyle::GetStyleSetName(), TEXT("ContentBrowser.AtsukkoIcon")),
		FExecuteAction::CreateRaw(this, &FAtsukkoToolKitModule::OnDeleteEmptyFoldersButtonClicked));

	MenuBuilder.AddMenuEntry(
		FText::FromString(TEXT("Advanced Deletion")),
		FText::FromString(TEXT("List assets by specific condition in a tab for deleting.")),
		FSlateIcon(FAtsukkoToolKitStyle::GetStyleSetName(), TEXT("ContentBrowser.AtsukkoIcon")),
		FExecuteAction::CreateRaw(this, &FAtsukkoToolKitModule::OnAdvancedDeletionButtonClicked));
}

void FAtsukkoToolKitModule::OnDeleteUnusedAssetsButtonClicked()
{
	if(ConstructedDockTab.IsValid())
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("Please close advance deletion tab before this operation."), true);
		return;
	}
	if(FolderPathsSelected.Num() > 1)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("You can only select one folder to delete unused assets!"), true);
		return;
	}
	TArray<FString> AssetsPathNames = UEditorAssetLibrary::ListAssets(FolderPathsSelected[0]);
	if(AssetsPathNames.Num() == 0)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("No asset found under selected folder."), false);
		return;
	}
	EAppReturnType::Type ConfirmedResult = DebugHeader::ShowDialog(
		EAppMsgType::YesNo,
		TEXT("A total of " + FString::FromInt(AssetsPathNames.Num()) + TEXT(" assets need to be checked. \nWould you like to proceed?")),
		false
		);

	if(ConfirmedResult == EAppReturnType::No) return;
	FixUpRedirectors();
	TArray<FAssetData> UnusedAssetsDataArray;
	for(const FString& AssetPathName : AssetsPathNames)
	{
		if(AssetPathName.Contains(TEXT("Developers"))||
			AssetPathName.Contains(TEXT("Collections"))||
			AssetPathName.Contains(TEXT("__ExternalActors__"))||
			AssetPathName.Contains(TEXT("__ExternalObjects__"))) continue;
		if(!UEditorAssetLibrary::DoesAssetExist(AssetPathName)) continue;

		TArray<FString> AssetReferences = 
		UEditorAssetLibrary::FindPackageReferencersForAsset(AssetPathName);

		if(AssetReferences.Num() == 0)
		{
			const FAssetData UnusedAssetData = UEditorAssetLibrary::FindAssetData(AssetPathName);
			UnusedAssetsDataArray.Add(UnusedAssetData);
		}
	}
	if(UnusedAssetsDataArray.Num() > 0)
	{
		ObjectTools::DeleteAssets(UnusedAssetsDataArray);
	}
	else
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("No unused assets under selected folder."), false);
	}
	
}

void FAtsukkoToolKitModule::OnDeleteEmptyFoldersButtonClicked()
{
	if(ConstructedDockTab.IsValid())
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("Please close advance deletion tab before this operation."), true);
		return;
	}
	
	FixUpRedirectors();
	
	auto FolderPathsArray = UEditorAssetLibrary::ListAssets(FolderPathsSelected[0], true, true);
	uint32 Counter = 0;

	FString EmptyFolderPathsNames;
	TArray<FString> EmptyFolderPathsArray;

	for(const FString& FolderPath : FolderPathsArray)
	{
		if(FolderPath.Contains(TEXT("Developers"))||
			FolderPath.Contains(TEXT("Collections"))||
			FolderPath.Contains(TEXT("__ExternalActors__"))||
			FolderPath.Contains(TEXT("__ExternalObjects__"))) continue;

		if(!UEditorAssetLibrary::DoesDirectoryExist(FolderPath)) continue;

		if(!UEditorAssetLibrary::DoesDirectoryHaveAssets(FolderPath))
		{
			EmptyFolderPathsNames.Append(FolderPath);
			EmptyFolderPathsNames.Append(TEXT("\n"));

			EmptyFolderPathsArray.Add(FolderPath);
		}
	}

	if(EmptyFolderPathsArray.Num()==0)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, TEXT("No empty folder found under selected folder"), false);
		return;
	}

	EAppReturnType::Type ConfirmResult = DebugHeader::ShowDialog(EAppMsgType::OkCancel,
	                                                 TEXT("Empty folders found in:\n") + EmptyFolderPathsNames +
	                                                 TEXT("\n Would you like to delete all?"), false);

	if(ConfirmResult == EAppReturnType::Cancel) return;

	for(const FString& EmptyFolder : EmptyFolderPathsArray)
	{
		UEditorAssetLibrary::DeleteDirectory(EmptyFolder) ? (void)++Counter : DebugHeader::Print(TEXT("Failed to delete folder: " + EmptyFolder), FColor::Red);
	}

	if(Counter > 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("Successfully deleted ") + FString::FromInt(Counter) + TEXT("folders."));
	}
		
}

void FAtsukkoToolKitModule::OnAdvancedDeletionButtonClicked()
{
	FixUpRedirectors();
	FGlobalTabmanager::Get()->TryInvokeTab(FName("Advance Deletion"));
}

void FAtsukkoToolKitModule::FixUpRedirectors()
{
	TArray<UObjectRedirector*> RedirectorsToFixArray;
	FAssetRegistryModule& AssetRegistryModule = 
	FModuleManager::Get().LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	
	FARFilter Filter;
	Filter.bRecursivePaths = true;
	Filter.PackagePaths.Emplace("/Game");
	Filter.ClassPaths.Emplace("/ObjectRedirector");
	//Filter.ClassNames.Emplace("ObjectRedirector");
	
	TArray<FAssetData> OutRedirectors;

	AssetRegistryModule.Get().GetAssets(Filter, OutRedirectors);

	for(const FAssetData& RedirectorData : OutRedirectors)
	{
		if(UObjectRedirector* RedirectorToFix = Cast<UObjectRedirector>(RedirectorData.GetAsset()))
		{
			RedirectorsToFixArray.Add(RedirectorToFix);
		}
	}

	FAssetToolsModule& AssetToolsModule = 
	FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools"));

	AssetToolsModule.Get().FixupReferencers(RedirectorsToFixArray);
}

#pragma endregion

















#pragma region CustomEditorTab

void FAtsukkoToolKitModule::RegisterAdvanceDeletionTab()
{
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(FName("Advance Deletion"),
		FOnSpawnTab::CreateRaw(this, &FAtsukkoToolKitModule::OnSpawnAdvanceDeletion))
		.SetDisplayName(FText::FromString(TEXT("Advance Deletion")));
}

TSharedRef<SDockTab> FAtsukkoToolKitModule::OnSpawnAdvanceDeletion(const FSpawnTabArgs& SpawnTabArgs)
{
	if(FolderPathsSelected.Num() == 0) return SNew(SDockTab).TabRole(ETabRole::NomadTab);
	ConstructedDockTab =
		SNew(SDockTab).TabRole(ETabRole::NomadTab)
		[
			SNew(SAdvanceDeletionTab)
			.AssetsDataToStore(GetAllAssetsDataUnderSelectedFolder())
			.CurrenSelectedFolder(FolderPathsSelected[0])
		];
	
	ConstructedDockTab->SetOnTabClosed(SDockTab::FOnTabClosedCallback::CreateRaw(this, &FAtsukkoToolKitModule::OnAdvanceDeletionTabClosed));
	
	return ConstructedDockTab.ToSharedRef();
}

TArray<TSharedPtr<FAssetData>> FAtsukkoToolKitModule::GetAllAssetsDataUnderSelectedFolder()
{
	TArray<TSharedPtr<FAssetData>> AvailableAssetsData;
	TArray<FString> AssetsPathNames = UEditorAssetLibrary::ListAssets(FolderPathsSelected[0]);

	for(FString& AssetPathName : AssetsPathNames)
	{
		// 上面的ListAssets返回ObjectPath，也就是类似../../AssetName.AssetName的样式，后面版本会被弃用，所以这里把它
		// 转换成../../AssetName的样式（PackageName的样式）
		AssetPathName = FPackageName::ObjectPathToPackageName(AssetPathName);
		
		if(AssetPathName.Contains(TEXT("Developers"))||
			AssetPathName.Contains(TEXT("Collections"))||
			AssetPathName.Contains(TEXT("__ExternalActors__"))||
			AssetPathName.Contains(TEXT("__ExternalObjects__"))) continue;
		if(!UEditorAssetLibrary::DoesAssetExist(AssetPathName)) continue;

		const FAssetData Data = UEditorAssetLibrary::FindAssetData(AssetPathName);

		AvailableAssetsData.Add(MakeShared<FAssetData>(Data));
	}
	
	return AvailableAssetsData;
}

void FAtsukkoToolKitModule::OnAdvanceDeletionTabClosed(TSharedRef<SDockTab> TabToClose)
{
	if(ConstructedDockTab.IsValid())
	{
		ConstructedDockTab.Reset();
		FolderPathsSelected.Empty();
	}
}

#pragma endregion



















#pragma region LevelEditorMenuExtension

void FAtsukkoToolKitModule::InitLevelEditorExtension()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	TArray<FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors>& LevelEditorMenuExtenders = 
	LevelEditorModule.GetAllLevelViewportContextMenuExtenders();
	LevelEditorMenuExtenders.Add(FLevelEditorModule::FLevelViewportMenuExtender_SelectedActors::CreateRaw(this, &FAtsukkoToolKitModule::CustomLevelEditorMenuExtender));
	
}

TSharedRef<FExtender> FAtsukkoToolKitModule::CustomLevelEditorMenuExtender(
	const TSharedRef<FUICommandList> UICommandList, const TArray<AActor*> SelectedActors)
{
	TSharedRef<FExtender> MenuExtender = MakeShareable(new FExtender());

	if(SelectedActors.Num() > 0)
	{
		MenuExtender->AddMenuExtension(
			FName("ActorOptions"),
			EExtensionHook::Before,
			UICommandList,
			FMenuExtensionDelegate::CreateRaw(this, &FAtsukkoToolKitModule::AddLevelEditorMenuEntry)
		);
	}
	return MenuExtender;
}

void FAtsukkoToolKitModule::AddLevelEditorMenuEntry(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.AddMenuEntry(
		FText::FromString(TEXT("Lock Actor Selection")),
		FText::FromString(TEXT("Prevent actor from being selected")),
		FSlateIcon(FAtsukkoToolKitStyle::GetStyleSetName(), "ContentBrowser.AtsukkoIcon"),
		FExecuteAction::CreateRaw(this, &FAtsukkoToolKitModule::OnLockActorSelectionButtonClicked)
	);
	MenuBuilder.AddMenuEntry(
		FText::FromString(TEXT("Unlock All Actor Selection")),
		FText::FromString(TEXT("Remove the selection constraint on all actors")),
		FSlateIcon(FAtsukkoToolKitStyle::GetStyleSetName(), "ContentBrowser.AtsukkoIcon"),
		FExecuteAction::CreateRaw(this, &FAtsukkoToolKitModule::OnUnlockActorSelectionButtonClicked)
	);
}

void FAtsukkoToolKitModule::OnLockActorSelectionButtonClicked()
{
	if(!GetEditorActorSubsystem()) return;
	TArray<class AActor*> SelectedActors = WeakEditorActorSubsystem->GetSelectedLevelActors();

	if(SelectedActors.Num() == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No actor selected."));
		return;
	}

	FString CurrentLockedActorNames = TEXT("Lock selection for: ");
	for (class AActor* SelectedActor : SelectedActors)
	{
		if(!SelectedActor) continue;
		LockActorSelection(SelectedActor);
		WeakEditorActorSubsystem->SetActorSelectionState(SelectedActor, false);

		CurrentLockedActorNames.Append(TEXT("\n"));
		CurrentLockedActorNames.Append(SelectedActor->GetActorLabel());
	}

	RefreshSceneOutliner();

	DebugHeader::ShowNotifyInfo(CurrentLockedActorNames);
}

void FAtsukkoToolKitModule::OnUnlockActorSelectionButtonClicked()
{
	if(!GetEditorActorSubsystem()) return;

	TArray<AActor*> AllActors = WeakEditorActorSubsystem->GetAllLevelActors();
	TArray<AActor*> AllLockedActors;

	for (auto Actor : AllActors)
	{
		if(!Actor) continue;

		if(CheckIsActorSelectionLocked(Actor))
		{
			AllLockedActors.Add(Actor);
		}
	}
	if(AllLockedActors.Num() == 0)
	{
		DebugHeader::ShowNotifyInfo(TEXT("No selection locked actor currently."));
		return;
	}
	FString UnlockedActorNames = TEXT("Lifted selection constraint for: ");

	for (AActor* LockedActor : AllLockedActors)
	{
		UnlockActorSelection(LockedActor);

		UnlockedActorNames.Append(TEXT("\n"));
		UnlockedActorNames.Append(LockedActor->GetActorLabel());
	}

	RefreshSceneOutliner();
	DebugHeader::ShowNotifyInfo(UnlockedActorNames);
}


#pragma endregion
















#pragma region SelectionLock

void FAtsukkoToolKitModule::InitCustomSelectionEvent()
{
	USelection* UserSelection = GEditor->GetSelectedActors();
	UserSelection->SelectObjectEvent.AddRaw(this, &FAtsukkoToolKitModule::OnActorSelected);
}

void FAtsukkoToolKitModule::OnActorSelected(UObject* SelectedObject)
{
	if(!GetEditorActorSubsystem()) return;
	if(AActor* SelectedActor = Cast<AActor>(SelectedObject))
	{
		if(CheckIsActorSelectionLocked(SelectedActor))
		{
			WeakEditorActorSubsystem->SetActorSelectionState(SelectedActor, false);
		}
		
	}
}

void FAtsukkoToolKitModule::LockActorSelection(AActor* ActorToProcess)
{
	if(!ActorToProcess) return;
	if(!ActorToProcess->ActorHasTag(FName(TEXT("Locked"))))
	{
		ActorToProcess->Tags.Add(FName(TEXT("Locked")));
	}
}

void FAtsukkoToolKitModule::UnlockActorSelection(AActor* ActorToProcess)
{
	if(!ActorToProcess) return;

	if(ActorToProcess->ActorHasTag(FName(TEXT("Locked"))))
	{
		ActorToProcess->Tags.Remove(FName(TEXT("Locked")));
	}
}

void FAtsukkoToolKitModule::RefreshSceneOutliner()
{
	FLevelEditorModule& LevelEditorModule =
		FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));

	TSharedPtr<ISceneOutliner> SceneOutliner = LevelEditorModule.GetFirstLevelEditor()->GetMostRecentlyUsedSceneOutliner();

	if(SceneOutliner.IsValid())
	{
		SceneOutliner->FullRefresh();
	}
}

bool FAtsukkoToolKitModule::CheckIsActorSelectionLocked(AActor* ActorToProcess)
{
	if(!ActorToProcess) return false;

	return ActorToProcess->ActorHasTag(FName(TEXT("Locked")));
}

void FAtsukkoToolKitModule::ProcessLockingForOutliner(AActor* ActorToProcess, bool bShouldLock)
{
	if(!GetEditorActorSubsystem()) return;
	if(bShouldLock)
	{
		LockActorSelection(ActorToProcess);

		WeakEditorActorSubsystem->SetActorSelectionState(ActorToProcess, false);

		DebugHeader::ShowNotifyInfo(TEXT("Locked selection for: \n") + ActorToProcess->GetActorLabel());
	}
	else
	{
		UnlockActorSelection(ActorToProcess);
		
		DebugHeader::ShowNotifyInfo(TEXT("Locked selection for: \n") + ActorToProcess->GetActorLabel());
	}
}

#pragma endregion

















#pragma region ProccessDataForAdvanceDeletionTab


bool FAtsukkoToolKitModule::DeleteSingleAssetForAssetList(const FAssetData& AssetDataToDelete)
{
	TArray<FAssetData> AssetDataForDeletion;
	AssetDataForDeletion.Add(AssetDataToDelete);
	
	if(ObjectTools::DeleteAssets(AssetDataForDeletion) > 0)
	{
		return true;
	}
	return false;
}

bool FAtsukkoToolKitModule::DeleteMultipleAssetsForAssetList(const TArray<FAssetData>& AssetDataToDeleteArray)
{
	if(ObjectTools::DeleteAssets(AssetDataToDeleteArray) > 0)
	{
		return true;
	}
	return false;
}

void FAtsukkoToolKitModule::ListUnusedAssetsForAssetList(const TArray<TSharedPtr<FAssetData>>& AssetDataToFilter,
	TArray<TSharedPtr<FAssetData>>& OutUnusedAssetData)
{
	OutUnusedAssetData.Empty();
	for(const TSharedPtr<FAssetData>& AssetDataPtr : AssetDataToFilter)
	{
		TArray<FString> AssetReferencers =
			UEditorAssetLibrary::FindPackageReferencersForAsset(FPackageName::ObjectPathToPackageName(AssetDataPtr->GetSoftObjectPath().ToString()));
		if(AssetReferencers.Num() == 0)
		{
			OutUnusedAssetData.Add(AssetDataPtr);
		}
	}
}

void FAtsukkoToolKitModule::ListRepeatedNameAssetsForAssetList(const TArray<TSharedPtr<FAssetData>>& AssetDataToFilter,
	TArray<TSharedPtr<FAssetData>>& OutSameNameAssetData)
{
	OutSameNameAssetData.Empty();
	
	TMultiMap<FString, TSharedPtr<FAssetData>> NameToAssetDataMap;
	for (const TSharedPtr<FAssetData>& AssetData : AssetDataToFilter)
	{
		NameToAssetDataMap.Emplace(AssetData->AssetName.ToString(), AssetData);
	}
	for(const TSharedPtr<FAssetData>& AssetData : AssetDataToFilter)
	{
		TArray<TSharedPtr<FAssetData>> OutAssetData;
		NameToAssetDataMap.MultiFind(AssetData->AssetName.ToString(), OutAssetData);

		if(OutAssetData.Num() <= 1) continue;
		for (const TSharedPtr<FAssetData>& SameNameAssetData : OutAssetData)
		{
			if(SameNameAssetData.IsValid())
			{
				OutSameNameAssetData.AddUnique(SameNameAssetData);
			}
		}
	}
}

void FAtsukkoToolKitModule::SyncCBToClickedAssetForAssetList(const FString& AssetPathToSync)
{
	TArray<FString> AssetPathToSyncArray;
	AssetPathToSyncArray.Add(AssetPathToSync);
	UEditorAssetLibrary::SyncBrowserToObjects(AssetPathToSyncArray);
}

#pragma endregion
















bool FAtsukkoToolKitModule::GetEditorActorSubsystem()
{
	if(!WeakEditorActorSubsystem.IsValid())
	{
		WeakEditorActorSubsystem = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
	}

	return WeakEditorActorSubsystem.IsValid();
}















#pragma region SceneOutlinerExtension

void FAtsukkoToolKitModule::InitSceneOutlinerColumnExtension()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(
		TEXT("SceneOutliner"));

	FSceneOutlinerColumnInfo SelectionLockColumnInfo(
		ESceneOutlinerColumnVisibility::Visible,
		1,
		FCreateSceneOutlinerColumn::CreateRaw(this, &FAtsukkoToolKitModule::OnCreateSelectionLockColumn)
	);
	
	SceneOutlinerModule.RegisterDefaultColumnType<FOutlinerSelectionLockColumn>(SelectionLockColumnInfo);
}

TSharedRef<ISceneOutlinerColumn> FAtsukkoToolKitModule::OnCreateSelectionLockColumn(ISceneOutliner& SceneOutliner)
{
	return MakeShareable(new FOutlinerSelectionLockColumn(SceneOutliner));
}

void FAtsukkoToolKitModule::UnRegisterSceneOutlinerColumnExtension()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(
		TEXT("SceneOutliner"));

	SceneOutlinerModule.UnRegisterColumnType<FOutlinerSelectionLockColumn>();
}

#pragma	endregion

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FAtsukkoToolKitModule, AtsukkoToolKit)
