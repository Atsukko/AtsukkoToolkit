// Fill out your copyright notice in the Description page of Project Settings.


#include "AssetActions/QuickAssetAction.h"

#include "AssetToolsModule.h"
#include "DebugHeader.h"

#include "EditorUtilityLibrary.h"
#include "EditorAssetLibrary.h"
#include "ObjectTools.h"
#include "AssetRegistry/AssetRegistryModule.h"


void UQuickAssetAction::DuplicateAsset(int32 num)
{
	if(num <= 0)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, "Invalid input.", true);
	}
	auto SelectedAssetsData = UEditorUtilityLibrary::GetSelectedAssetData();
	
	int Counter = 0;
	for(const auto& AssetData : SelectedAssetsData)
	{
		for(auto i = 0; i < num; i++)
		{
			auto SourceAssetPath = AssetData.GetSoftObjectPath().ToString();
			auto NewDupAssetName = AssetData.AssetName.ToString() + TEXT("_") + FString::FromInt(i + 1);
			auto DestinationAssetPath = FPaths::Combine(AssetData.PackagePath.ToString(), NewDupAssetName);

			if(UEditorAssetLibrary::DuplicateAsset(SourceAssetPath, DestinationAssetPath))
			{
				UEditorAssetLibrary::SaveAsset(DestinationAssetPath, false);
				++Counter;
			}
		}
		if(Counter > 0)
		{
			DebugHeader::ShowNotifyInfo("Successfully duplicated " + FString::FromInt(Counter) + " files.");
		}
	}
	
}

void UQuickAssetAction::AddPrefixes()
{
	TArray<UObject*> SelectedAssets = UEditorUtilityLibrary::GetSelectedAssets();
	uint32 Counter = 0;

	for(auto SelectedAsset : SelectedAssets)
	{
		if(!SelectedAsset) continue;

		FString* PrefixFound = PrefixMap.Find(SelectedAsset->GetClass());
		FString OldName = SelectedAsset->GetName();
		if(!PrefixFound || PrefixFound->IsEmpty())
		{
			DebugHeader::PrintLog(SelectedAsset->GetName() + TEXT(" prefix not found."));
			continue;
		};

		if(OldName.StartsWith(*PrefixFound))
		{
			DebugHeader::PrintLog(SelectedAsset->GetName() + TEXT(" already has prefix.") + *PrefixFound);
			continue;
		}

		if(SelectedAsset->IsA<UMaterialInstanceConstant>())
		{
			OldName.RemoveFromStart(TEXT("M_"));
			OldName.RemoveFromEnd(TEXT("_Inst"));
		}

		auto NewNameWithPrefix = *PrefixFound + OldName;

		UEditorUtilityLibrary::RenameAsset(SelectedAsset, NewNameWithPrefix);
		++Counter;
	}
	DebugHeader::ShowNotifyInfo(TEXT("Successfully added prefixes to ") + FString::FromInt(Counter) + " files.");
}

void UQuickAssetAction::RemoveUnusedAssets()
{
	FixUpRedirectors();
	
	TArray<FAssetData> SelectedAssetData = UEditorUtilityLibrary::GetSelectedAssetData();
	TArray<FAssetData> UnusedAssetData;
	for(const auto& AssetData : SelectedAssetData)
	{
		if(UEditorAssetLibrary::FindPackageReferencersForAsset(AssetData.GetSoftObjectPath()/*ObjectPath*/.ToString()).Num() == 0)
		{
			UnusedAssetData.Add(AssetData);
		}
	}
	DebugHeader::Print(FString::FromInt(UnusedAssetData.Num()), FColor::Green);
	if(UnusedAssetData.Num() == 0)
	{
		DebugHeader::ShowDialog(EAppMsgType::Ok, "No unused assets found.", false);
		return;
	}
	
	const int32 NumOfAssetsDeleted = ObjectTools::DeleteAssets(UnusedAssetData);
	
	if(NumOfAssetsDeleted == 0) return;

	DebugHeader::ShowNotifyInfo(TEXT("Successfully deleted ") + FString::FromInt(NumOfAssetsDeleted) + TEXT(" unused assets."));
}

void UQuickAssetAction::FixUpRedirectors()
{
	TArray<UObjectRedirector*> RedirectorsToFixArray;

	FAssetRegistryModule& AssetRegistryModule = 
	FModuleManager::Get().LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));

	FARFilter Filter;
	Filter.bRecursivePaths = true;
	Filter.PackagePaths.Emplace("/Game");
	Filter.ClassPaths.Emplace("ObjectRedirector");
	// Filter.ClassNames.Emplace("ObjectRedirector");

	TArray<FAssetData> OutRedirectors;
	
	AssetRegistryModule.Get().GetAssets(Filter, OutRedirectors);

	for(const FAssetData& RedirectorData : OutRedirectors)
	{
		if(UObjectRedirector* RedirectorToFix = Cast<UObjectRedirector>(RedirectorData.GetAsset()))
		{
			RedirectorsToFixArray.Add(RedirectorToFix);
		}
	}

	FAssetToolsModule& AssetToolsModule = 
	FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools"));

	AssetToolsModule.Get().FixupReferencers(RedirectorsToFixArray);
}
