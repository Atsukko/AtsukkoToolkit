// Fill out your copyright notice in the Description page of Project Settings.


#include "CustomStyle/AtsukkoToolKitStyle.h"

#include "DebugHeader.h"
#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleRegistry.h"

FName FAtsukkoToolKitStyle::StyleSetName = FName("AtsukkoToolKitStyle");
TSharedPtr<FSlateStyleSet> FAtsukkoToolKitStyle::CreatedSlateStyleSet = nullptr;

void FAtsukkoToolKitStyle::InitializeIcons()
{
	if(!CreatedSlateStyleSet.IsValid())
	{
		CreatedSlateStyleSet = CreateStyleSet();
		FSlateStyleRegistry::RegisterSlateStyle(*CreatedSlateStyleSet);
	}
	
}

TSharedRef<FSlateStyleSet> FAtsukkoToolKitStyle::CreateStyleSet()
{
	TSharedRef<FSlateStyleSet> CustomSlateStyleSet = MakeShareable(
		new FSlateStyleSet(StyleSetName));

	const FString IconDir = IPluginManager::Get().FindPlugin(TEXT("AtsukkoToolKit"))->GetBaseDir() /"Resources";

	const FVector2D Icon16x16(16.f, 16.f);
	
	CustomSlateStyleSet->SetContentRoot(IconDir);
	CustomSlateStyleSet->Set("ContentBrowser.AtsukkoIcon",
		new FSlateImageBrush(IconDir/"1.png", Icon16x16));

	const FCheckBoxStyle SelectionLockToggleButtonStyle =
		FCheckBoxStyle()
		.SetCheckBoxType(ESlateCheckBoxType::ToggleButton)
		.SetPadding(FMargin(10.f))

		.SetUncheckedImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::White25))
		.SetUncheckedHoveredImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::ForegroundHover))
		.SetUncheckedPressedImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::Foreground))

		.SetCheckedImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::Foreground))
		.SetCheckedHoveredImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::ForegroundHover))
		.SetCheckedPressedImage(FSlateImageBrush(IconDir / "1.png", Icon16x16, FStyleColors::AccentGray));

	CustomSlateStyleSet->Set("SceneOutliner.SelectionLock", SelectionLockToggleButtonStyle);
	
	return CustomSlateStyleSet;
}

void FAtsukkoToolKitStyle::ShutDown()
{
	if(CreatedSlateStyleSet.IsValid())
	{
		FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedSlateStyleSet);
		CreatedSlateStyleSet.Reset();
	}
}

