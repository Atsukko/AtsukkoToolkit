// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Styling/SlateStyle.h"

class FAtsukkoToolKitStyle
{
public:
	static void InitializeIcons();
	static void ShutDown();
private:
	static FName StyleSetName;
	
	static TSharedRef<FSlateStyleSet> CreateStyleSet();
	static TSharedPtr<FSlateStyleSet> CreatedSlateStyleSet;

public:
	static FName GetStyleSetName() { return StyleSetName; }
	static TSharedRef<FSlateStyleSet> GetCreatedSlateStyleSet() {return CreatedSlateStyleSet.ToSharedRef();}
};