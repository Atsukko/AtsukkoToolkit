// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class UEditorActorSubsystem;

class FAtsukkoToolKitModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:

#pragma region ContentBrowserMenuExtension
	/** 
	* Called on startup to initialize the Content Browser Menu Extension.
	* 
	* @param 
	* @return 
	* @author Atsukko
	*/
	void InitCBMenuExtension();

	/** 
	* Called to set the position of the menu entry.
	* 
	* @param 
	* @return 
	* @author Atsukko
	*/
	TSharedRef<FExtender> CustomCBMenuExtender(const TArray<FString>& SelectedPaths);

	/** 
	* Called to set the details of the menu entry.
	* 
	* @param 
	* @return 
	* @author Atsukko
	*/
	void AddCBMenuEntry(FMenuBuilder& MenuBuilder);

	/** 
	* Called when the menu entry is clicked.
	* 
	* @param 
	* @return 
	* @author Atsukko
	*/
	void OnDeleteUnusedAssetsButtonClicked();
	void OnDeleteEmptyFoldersButtonClicked();
	void OnAdvancedDeletionButtonClicked();

	void FixUpRedirectors();

private:
	TArray<FString> FolderPathsSelected;
#pragma endregion

#pragma region CustomEditorTab

	void RegisterAdvanceDeletionTab();

	TSharedRef<SDockTab> OnSpawnAdvanceDeletion(const FSpawnTabArgs& SpawnTabArgs);
	TSharedPtr<SDockTab> ConstructedDockTab;

	TArray<TSharedPtr<FAssetData>> GetAllAssetsDataUnderSelectedFolder();

	void OnAdvanceDeletionTabClosed(TSharedRef<SDockTab> TabToClose);
	
#pragma endregion

#pragma region LevelEditorMenuExtension

	void InitLevelEditorExtension();
	TSharedRef<FExtender> CustomLevelEditorMenuExtender(const TSharedRef<FUICommandList> UICommandList, const TArray<AActor*> SelectedActors);

	void AddLevelEditorMenuEntry(FMenuBuilder& MenuBuilder);

	void OnLockActorSelectionButtonClicked();
	void OnUnlockActorSelectionButtonClicked();
#pragma endregion

#pragma region SelectionLock

	void InitCustomSelectionEvent();

	void OnActorSelected(UObject* SelectedObject);

	void LockActorSelection(AActor* ActorToProcess);
	void UnlockActorSelection(AActor* ActorToProcess);

	void RefreshSceneOutliner();
	
#pragma endregion

	TWeakObjectPtr<UEditorActorSubsystem> WeakEditorActorSubsystem;

	bool GetEditorActorSubsystem();
public:
#pragma region ProccessDataForAdvanceDeletionTab

	bool DeleteSingleAssetForAssetList(const FAssetData& AssetDataToDelete);
	bool DeleteMultipleAssetsForAssetList(const TArray<FAssetData>& AssetDataToDeleteArray);
	void ListUnusedAssetsForAssetList(const TArray<TSharedPtr<FAssetData>>& AssetDataToFilter, TArray<TSharedPtr<FAssetData>>& OutUnusedAssetData);
	void ListRepeatedNameAssetsForAssetList(const TArray<TSharedPtr<FAssetData>>& AssetDataToFilter, TArray<TSharedPtr<FAssetData>>& OutSameNameAssetData);
	void SyncCBToClickedAssetForAssetList(const FString& AssetPathToSync);
	
#pragma endregion

#pragma region SceneOutlinerExtension

	void InitSceneOutlinerColumnExtension();
	
	TSharedRef<class ISceneOutlinerColumn> OnCreateSelectionLockColumn(class ISceneOutliner& SceneOutliner);
	void UnRegisterSceneOutlinerColumnExtension();
#pragma	endregion

	bool CheckIsActorSelectionLocked(AActor* ActorToProcess);
	void ProcessLockingForOutliner(AActor* ActorToProcess, bool bShouldLock);
};
