// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EditorUtilityWidget.h"
#include "QuickActorActionsWidget.generated.h"

UENUM(BlueprintType)
enum class E_DuplicationAxis : uint8
{
	EDA_XAxis UMETA(DisplayName = "X Axis"),
	EDA_YAxis UMETA(DisplayName = "Y Axis"),
	EDA_ZAxis UMETA(DisplayName = "Z Axis"),
	EDA_MAX UMETA(DisplayName = "Default Max")
};

UENUM(BlueprintType)
enum class E_RandomScaleMode : uint8
{
	DRSM_Uniform UMETA(DisplayName = "Uniform"),
	DRSM_Specific UMETA(DisplayName = "Specific"),
	DRSM_Max UMETA(DisplayName = "Default Max")
};

USTRUCT(BlueprintType)
struct FRandomActorRotation
{
	GENERATED_BODY()
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeRotYaw = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotYaw"), Category="RandomizeActorTransform")
	float RotYawMin = -45.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotYaw"), Category="RandomizeActorTransform")
	float RotYawMax = 45.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeRotPitch = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotPitch"), Category="RandomizeActorTransform")
	float RotPitchMin = -45.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotPitch"), Category="RandomizeActorTransform")
	float RotPitchMax = 45.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeRotRoll = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotRoll"), Category="RandomizeActorTransform")
	float RotRollMin = -45.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeRotRoll"), Category="RandomizeActorTransform")
	float RotRollMax = 45.f;
	
};

USTRUCT(BlueprintType)
struct FRandomActorOffset
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeOffsetX = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetX"), Category="RandomizeActorTransform")
	float OffsetXMin = -50.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetX"), Category="RandomizeActorTransform")
	float OffsetXMax = 50.f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeOffsetY = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetY"), Category="RandomizeActorTransform")
	float OffsetYMin = -50.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetY"), Category="RandomizeActorTransform")
	float OffsetYMax = 50.f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomizeOffsetZ = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetZ"), Category="RandomizeActorTransform")
	float OffsetZMin = -50.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeOffsetZ"), Category="RandomizeActorTransform")
	float OffsetZMax = 50.f;
};

USTRUCT(BlueprintType)
struct FRandomActorScale
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="RandomizeActorTransform")
	bool bRandomScale = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomScale"), Category="RandomizeActorTransform")
	E_RandomScaleMode RandomScaleMode = E_RandomScaleMode::DRSM_Uniform;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "RandomScaleMode == E_RandomScaleMode::DRSM_Uniform && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleMin = .5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "RandomScaleMode == E_RandomScaleMode::DRSM_Uniform && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleMax = 1.5f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	bool bRandomizeScaleX = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleX && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleXMin = .5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleX && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleXMax = 1.5f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	bool bRandomizeScaleY = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleY && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleYMin = .5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleY && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleYMax = 1.5f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	bool bRandomizeScaleZ = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleZ && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleZMin = .5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(EditCondition = "bRandomizeScaleZ && RandomScaleMode == E_RandomScaleMode::DRSM_Specific && bRandomScale", EditConditionHides), Category="RandomizeActorTransform")
	float ScaleZMax = 1.5f;
};

/**
 * 
 */
UCLASS()
class ATSUKKOTOOLKIT_API UQuickActorActionsWidget : public UEditorUtilityWidget
{
	GENERATED_BODY()


public:
#pragma region ActorBatchSelection
	UFUNCTION(BlueprintCallable, Category="ActorBatchSelection")
	void SelectAllActorsWithSimilarName();
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ActorBatchSelection")
	TEnumAsByte<ESearchCase::Type> SearchCase = ESearchCase::IgnoreCase;
#pragma endregion

#pragma region ActorBatchDuplication

	UFUNCTION(BlueprintCallable, Category="ActorBatchDuplication")
	void DuplicateActors();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ActorBatchDuplication")
	int32 NumberOfDuplicates = 5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ActorBatchDuplication")
	E_DuplicationAxis AxisForDuplication = E_DuplicationAxis::EDA_XAxis;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "ActorBatchDuplication")
	float Offset = 300.f;
	
#pragma endregion

#pragma region RandomizeActorTransform

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomizeActorTransform")
	FRandomActorOffset RandomActorOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomizeActorTransform")
	FRandomActorRotation RandomActorRotation;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomizeActorTransform")
	FRandomActorScale RandomActorScale;
	
	UFUNCTION(BlueprintCallable, Category = "RandomizeActorTransform")
	void RandomizeActorTransform();
	
#pragma endregion
	
private:
	UPROPERTY()
	class UEditorActorSubsystem* EditorActorSubsystem;

	bool GetEditorActorSubsystem();
};
