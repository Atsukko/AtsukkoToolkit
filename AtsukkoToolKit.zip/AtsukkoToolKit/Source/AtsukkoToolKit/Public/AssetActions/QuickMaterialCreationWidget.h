// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EditorUtilityWidget.h"
#include "QuickMaterialCreationWidget.generated.h"

UENUM(BlueprintType)
enum class E_ChannelPackingType : uint8
{
	ECPT_NoChannelPacking UMETA(DisplayName = "No Channel Packing"),
	ECPT_ORM UMETA(DisplayName = "OcclusionRoughnessMetallic"),
	ECPT_MAX UMETA(DisplayName = "DefaultMAX"),
};

class UMaterialExpressionTextureSample;
/**
 * 
 */
UCLASS()
class ATSUKKOTOOLKIT_API UQuickMaterialCreationWidget : public UEditorUtilityWidget
{
	GENERATED_BODY()

public:
#pragma region QuickMaterialCreation

	UFUNCTION(BlueprintCallable, Category = "CreateMaterialFromSelectedTextures")
	void CreateMaterialFromSelectedTextures();


	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CreateMaterialFromSelectedTextures")
	E_ChannelPackingType ChannelPackingType = E_ChannelPackingType::ECPT_NoChannelPacking;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CreateMaterialFromSelectedTextures")
	bool bCustomMaterialName = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CreateMaterialFromSelectedTextures")
	bool bCreateMaterialInstance = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "CreateMaterialFromSelectedTextures", meta = (EditCondition = "bCustomMaterialName"))
	FString MaterialName = TEXT("M_");
#pragma endregion


#pragma region SupportedTextureNames
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> BaseColorArray = {
		TEXT("_BaseColor"),
		TEXT("_Albedo"),
		TEXT("_Diffuse"),
		TEXT("_diff"),
		TEXT("_D"),
		TEXT("_C")
	};

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> MetallicArray = {
		TEXT("_Metallic"),
		TEXT("_metal"),
		TEXT("_M")
	};
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> RoughnessArray = {
		TEXT("_Roughness"),
		TEXT("_RoughnessMap"),
		TEXT("_rough"),
		TEXT("_R")
	};
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> NormalArray = {
		TEXT("_Normal"),
		TEXT("_NormalMap"),
		TEXT("_N"),
		TEXT("_nor")
	};
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> AmbientOcclusionArray = {
		TEXT("_AmbientOcclusion"),
		TEXT("_AmbientOcclusionMap"),
		TEXT("_AO"),
		TEXT("_O")
	};
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SupportedTextureNames")
	TArray<FString> ORMArray = {
		TEXT("_ORM"),
		TEXT("_orm"),
		TEXT("_arm"),
		TEXT("_OcclusionRoughnessMetallic")
	};
#pragma endregion
	
#pragma region QuickMaterialCreationCore

	/** 
	 * Process the selected data, will filter out textures, and return false if non-texture selected.
	 * 
	 * @param SelectedDataToProcess Selected assets data.
	 * @param OutSelectedTexturesArray Selected textures if process is successful.
	 * @param OutSelectedTexturePackagePath Path of selected textures if process is successful.
	 * @return Whether the process is successful.
	 * @author Atsukko
	 */
	bool ProcessSelectedData(const TArray<FAssetData>& SelectedDataToProcess, TArray<UTexture2D*>& OutSelectedTexturesArray, FString& OutSelectedTexturePackagePath);

	/** 
	 * Check if the material name is already used by other asset under the same folder.
	 * 
	 * @param FolderPathToCheck Selected assets data.
	 * @param MaterialNameToCheck Selected textures if process is successful.
	 * @return Whether the material name is already used.
	 * @author Atsukko
	 */
	bool CheckIsNameUsed(const FString& FolderPathToCheck, const FString& MaterialNameToCheck);

	/** 
	 * Create a material asset.
	 * 
	 * @param NameOfTheMaterial Material name.
	 * @param PathToStoreTheMaterial Target path to create the material.
	 * @return Material created.
	 * @author Atsukko
	 */
	UMaterial* CreateMaterialAsset(const FString& NameOfTheMaterial, const FString& PathToStoreTheMaterial);

	UMaterialInstance* CreateMaterialInstance(UMaterial* SourceMaterial, const FString& SelectedTextureFolderPath);

	void Default_CreateMaterialNodes(UMaterial* CreatedMaterial, UTexture2D* SelectedTexture, uint32& PinsConnectedCounter);
	void ORM_CreateMaterialNodes(UMaterial* CreatedMaterial, UTexture2D* SelectedTexture, uint32& PinsConnectedCounter);
#pragma endregion

#pragma region CreateMaterialNodesConnetctPins

	bool TryConnectBaseColor(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	bool TryConnectMetallic(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	bool TryConnectRoughness(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	bool TryConnectNormal(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	bool TryConnectAmbientOcclusion(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	bool TryConnectORM(UMaterialExpressionTextureSample* TextureSampleNode, UTexture2D* SelectedTexture, UMaterial* CreatedMaterial);
	
#pragma endregion
};
