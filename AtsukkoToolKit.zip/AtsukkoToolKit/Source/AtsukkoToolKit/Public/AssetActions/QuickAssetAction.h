// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AssetActionUtility.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Particles/ParticleSystem.h"
#include "Sound/SoundCue.h"
#include "QuickAssetAction.generated.h"

/**
 * 
 */
UCLASS()
class ATSUKKOTOOLKIT_API UQuickAssetAction : public UAssetActionUtility
{
	GENERATED_BODY()
	
public:
	
	/** 
	 * Duplicate selected assets a specified number of times.
	 * 
	 * @param num Number of copies will be created.  
	 * @return 
	 * @author Atsukko
	 */
	UFUNCTION(CallInEditor)
	void DuplicateAsset(int32 num);

	/** 
	 * Add prefixes to the names of selected assets.
	 * 
	 * @param 
	 * @return 
	 * @author Atsukko
	 */
	UFUNCTION(CallInEditor)
	void AddPrefixes();

	/** 
	 * Delete assets which are not referenced by anything else.
	 *
	 * @param 
	 * @return 
	 * @author Atsukko
	 */
	UFUNCTION(CallInEditor)
	void RemoveUnusedAssets();

private:
	TMap<UClass*, FString> PrefixMap =
	{
		{UBlueprint::StaticClass(), "BP_"},
		{UStaticMesh::StaticClass(), "SM_"},
		{UMaterial::StaticClass(), "M_"},
		{UMaterialFunctionInterface::StaticClass(), "MF_"},
		{UParticleSystem::StaticClass(), "PS_"},
		{UTexture::StaticClass(), "T_"},
		{UTexture2D::StaticClass(), "T_"},
		{UMaterialInstanceConstant::StaticClass(), "MI_"},
		{USoundCue::StaticClass(), "SC_"},
		{USoundWave::StaticClass(), "SW_"},
		{USkeletalMesh::StaticClass(), "SK_"},
		{UActorComponent::StaticClass(), "AC_"},
		{UEnum::StaticClass(), "E_"},
		//{UUserWidget::StaticClass(), "WBP_"},
		{UAnimBlueprint::StaticClass(), "ABP_"},
		{UAnimationAsset::StaticClass(), "A_"},
		{UAnimMontage::StaticClass(), "AM_"},
	};

	void FixUpRedirectors();
};
