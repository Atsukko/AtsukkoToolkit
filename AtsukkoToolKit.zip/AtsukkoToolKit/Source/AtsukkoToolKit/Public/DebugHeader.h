﻿#pragma once

#include "Framework/Notifications/NotificationManager.h"
#include "Misc/MessageDialog.h"
#include "Widgets/Notifications/SNotificationList.h"


namespace DebugHeader
{
	/** 
	 * Print message on screen.
	 * @param Message Message content.
	 * @param Color Font color.
	 * @return 
	 * @author Atsukko
	 */
	static void Print(const FString& Message, const FColor& Color = FColor::White)
	{
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 5.f, Color, Message);
		}
	}

	/** 
	 * Print message in console.
	 * @param Message 
	 * @return 
	 * @author Atsukko
	 */
	static void PrintLog(const FString& Message)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *Message);
	}

	/** 
	 * Print message in dialog.
	 *
	 * @param MsgType Message type.
	 * @param Message Message content.
	 * @param bShowMsgAsWarning Whether to show message as warning.
	 * @return Type of button user clicked.
	 * @author Atsukko
	 */
	static EAppReturnType::Type ShowDialog(EAppMsgType::Type MsgType, const FString& Message, bool bShowMsgAsWarning = true)
	{
		if(bShowMsgAsWarning)
		{
			return FMessageDialog::Open(MsgType, FText::FromString(Message), FText::FromString("Warning"));
		}
		else
		{
			return FMessageDialog::Open(MsgType, FText::FromString(Message));
		}
	}

	/** 
	 * Print message in notify.
	 * @param Message Message content.
	 * @return 
	 * @author Atsukko
	 */
	static void ShowNotifyInfo(const FString& Message)
	{
		FNotificationInfo NotifyInfo(FText::FromString(Message));
		NotifyInfo.bUseLargeFont = true;
		NotifyInfo.FadeOutDuration = 5.f;
		
		FSlateNotificationManager::Get().AddNotification(NotifyInfo);
	}
	
}
